"use client";

import { useState } from "react";

export default function AdminPanel() {
  const [publicaciones, setPublicaciones] = useState([
    { id: 1, nombre: "Caja de cartón grande", tipo: "Cartón" },
    { id: 2, nombre: "Lata de bebida", tipo: "Lata" },
    { id: 3, nombre: "Botella de vidrio", tipo: "Vidrio" },
  ]);

  const handleEliminar = (id) => {
    if (confirm("¿Seguro que quieres eliminar esta publicación?")) {
      setPublicaciones(publicaciones.filter((p) => p.id !== id));
      alert("Publicación eliminada correctamente.");
    }
  };

  return (
    <main className="min-h-screen bg-[#f5f7f5] px-6 md:px-10 py-10">
      <h1 className="text-4xl md:text-5xl font-bold text-purple-700 mb-8">
        Panel Administrador 👨‍💼
      </h1>

      <p className="text-gray-700 mb-6">
        Desde aquí puedes revisar las publicaciones y eliminar aquellas que
        no cumplan con los requisitos.
      </p>

      <div className="grid gap-6 md:grid-cols-2">
        {publicaciones.map((pub) => (
          <div
            key={pub.id}
            className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 flex flex-col justify-between"
          >
            <div>
              <h2 className="text-xl font-bold text-purple-600 mb-2">
                {pub.nombre}
              </h2>
              <p className="text-gray-700 mb-2">
                Tipo: {pub.tipo}
              </p>
            </div>
            <button
              onClick={() => handleEliminar(pub.id)}
              className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-red-700 mt-4"
            >
              ❌ Eliminar publicación
            </button>
          </div>
        ))}
      </div>
    </main>
  );
}