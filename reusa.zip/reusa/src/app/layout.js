"use client";

import "./globals.css";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function RootLayout({ children }) {
  const pathname = usePathname();

  const menuItems = [
    { name: "Inicio", href: "/" },
    { name: "Explorar", href: "/explorar" },
    { name: "Publicar", href: "/publicar" },
    { name: "Centros cercanos", href: "/centros" },
    { name: "Cómo funciona", href: "/como-funciona" },
  ];

  return (
    <html lang="es">
      <body className="bg-purple-600 text-gray-900">
        <header className="bg-white shadow-sm">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 px-6 md:px-10 py-4">
            <Link href="/" className="flex items-center gap-3">
              <img src="/logo-reusa.png" alt="Logo ReUsa" className="h-16 w-auto" />
              <div>
                <h1 className="text-2xl font-bold">
                  <span className="text-blue-600">Re</span>
                  <span className="text-purple-600">Usa</span>
                </h1>
                <p className="text-sm text-gray-500">Conecta y Recicla</p>
              </div>
            </Link>

            <nav className="flex flex-wrap justify-center gap-5 md:gap-7 text-purple-600 font-medium">
              {menuItems.map(
                (item) =>
                  pathname !== item.href && (
                    <Link key={item.href} href={item.href} className="hover:text-purple-800">
                      {item.name}
                    </Link>
                  )
              )}
            </nav>

<div className="flex items-center gap-3">
  {pathname !== "/login" && (
    <Link
      href="/login"
      className="border border-green-600 text-green-600 px-5 py-2 rounded-lg font-semibold hover:bg-green-50"
    >
      Iniciar sesión
    </Link>
  )}

  {pathname !== "/registro" && (
    <Link
      href="/registro"
      className="bg-green-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-green-700"
    >
      Registrarse
    </Link>
  )}
</div>
          </div>
        </header>

      

        {children}
      </body>
    </html>
  );
}