"use client";

import { useState } from "react";

export default function Publicar() {
  const [logueado, setLogueado] = useState(false);

  const [formulario, setFormulario] = useState({
    nombre: "",
    tipo: "",
    descripcion: "",
    ubicacion: "",
    contacto: "",
  });

  const handleChange = (e) => {
    setFormulario({
      ...formulario,
      [e.target.name]: e.target.value,
    });
  };

  const handlePublicar = (e) => {
    e.preventDefault();

    if (!logueado) {
      alert("Debes iniciar sesión o registrarte para publicar un material.");
      return;
    }

    alert("Publicación creada correctamente. Esta función luego se conectará a Supabase.");
  };

  return (
    <main className="min-h-screen bg-[#f5f7f5] p-6 md:p-10 text-gray-900">
      <div className="mb-6">
        <a
          href="/"
          className="text-purple-600 font-bold hover:underline flex items-center gap-1"
        >
          ← Volver atrás
        </a>
      </div>

      <section className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-purple-700 mb-3">
            Publicar material
          </h1>

          <p className="text-gray-600 text-lg">
            Completa la información del material que quieres reutilizar o entregar.
            Por ahora el prototipo se enfoca en la comuna de Ñuñoa.
          </p>
        </div>

        {!logueado && (
          <div className="bg-yellow-50 border border-yellow-300 text-yellow-800 rounded-xl p-5 mb-8">
            <h2 className="font-bold text-lg mb-2">
              Debes iniciar sesión para publicar
            </h2>
            <p className="mb-4">
              Puedes explorar publicaciones sin cuenta, pero para publicar un material
              es necesario iniciar sesión o registrarse.
            </p>

            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setLogueado(true)}
                className="bg-green-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-green-700"
              >
                Simular inicio de sesión
              </button>

              <a
                href="/login"
                className="border border-green-600 text-green-600 px-5 py-2 rounded-lg font-semibold hover:bg-green-50"
              >
                Ir a iniciar sesión
              </a>

              <a
                href="/registro"
                className="border border-purple-600 text-purple-600 px-5 py-2 rounded-lg font-semibold hover:bg-purple-50"
              >
                Registrarme
              </a>
            </div>
          </div>
        )}

        <form
          onSubmit={handlePublicar}
          className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 md:p-8 grid gap-6"
        >
          <div>
            <label className="block font-semibold mb-2">
              Nombre del material
            </label>
            <input
              type="text"
              name="nombre"
              value={formulario.nombre}
              onChange={handleChange}
              placeholder="Ej: Caja de cartón, botellas de vidrio, latas limpias"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div>
            <label className="block font-semibold mb-2">
              Tipo de material
            </label>
            <select
              name="tipo"
              value={formulario.tipo}
              onChange={handleChange}
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            >
              <option value="">Selecciona una opción</option>
              <option value="Cartón">Cartón</option>
              <option value="Lata">Lata</option>
              <option value="Vidrio">Vidrio</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-2">
              Descripción breve
            </label>
            <textarea
              name="descripcion"
              value={formulario.descripcion}
              onChange={handleChange}
              placeholder="Describe el estado, cantidad o detalles del material."
              rows="4"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            ></textarea>
          </div>

          <div>
            <label className="block font-semibold mb-2">
              Ubicación referencial para retiro
            </label>
            <input
              type="text"
              name="ubicacion"
              value={formulario.ubicacion}
              onChange={handleChange}
              placeholder="Ej: Ñuñoa, cerca de Plaza Ñuñoa"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
            <p className="text-sm text-gray-500 mt-2">
              Por seguridad, evita publicar datos demasiado personales. Usa una referencia general.
            </p>
          </div>

          <div>
            <label className="block font-semibold mb-2">
              Contacto para coordinación
            </label>
            <input
              type="text"
              name="contacto"
              value={formulario.contacto}
              onChange={handleChange}
              placeholder="Ej: correo o teléfono de contacto"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div>
            <label className="block font-semibold mb-2">
              Imagen del material
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center text-gray-500 bg-gray-50">
              Aquí irá la imagen del material cuando se conecte la subida de archivos.
            </div>
          </div>

          <button
            type="submit"
            className="bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition"
          >
            Publicar material
          </button>
        </form>
      </section>
    </main>
  );
}