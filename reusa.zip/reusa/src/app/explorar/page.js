"use client";

import { useState } from "react";

export default function Explorar() {
  const [productos, setProductos] = useState([
    {
      id: 1,
      nombre: "Caja de cartón grande",
      tipo: "Cartón",
      descripcion: "Caja de cartón reciclable, buena para mudanza.",
      ubicacion: "Ñuñoa",
      estado: "Disponible",
    },
    {
      id: 2,
      nombre: "Lata de bebida",
      tipo: "Lata",
      descripcion: "Lata limpia, sin abrir, para reciclaje.",
      ubicacion: "Ñuñoa",
      estado: "Disponible",
    },
    {
      id: 3,
      nombre: "Botella de vidrio",
      tipo: "Vidrio",
      descripcion: "Botella de vidrio vacía, para reutilizar.",
      ubicacion: "Ñuñoa",
      estado: "Disponible",
    },
  ]);

  const handleSolicitar = (id) => {
    setProductos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, estado: "Reservado" } : p))
    );
    alert(
      "Has reservado este material. Contacta al publicador para coordinar."
    );
  };

  return (
    <main className="min-h-screen bg-[#f5f7f5] p-6 md:p-10">
      {/* Volver atrás */}
      <div className="mb-6">
        <a
          href="/"
          className="text-purple-600 font-bold hover:underline flex items-center gap-1"
        >
          ← Volver atrás
        </a>
      </div>

      <h1 className="text-4xl md:text-5xl font-bold text-purple-700 mb-8">
        Explorar productos
      </h1>

      <div className="grid gap-6">
        {productos.map((p) => (
          <div
            key={p.id}
            className="bg-white rounded-xl shadow-md p-6 border border-gray-100 flex flex-col md:flex-row items-center gap-6"
          >
            <div className="flex-1">
              <h2 className="text-xl font-bold text-purple-600 mb-2">
                {p.nombre}
              </h2>
              <p className="text-gray-700 mb-1">
                <strong>Tipo:</strong> {p.tipo}
              </p>
              <p className="text-gray-700 mb-1">
                <strong>Descripción:</strong> {p.descripcion}
              </p>
              <p className="text-gray-700 mb-2">
                <strong>Ubicación:</strong> {p.ubicacion}
              </p>
              <p className="text-gray-700 mb-3">
                <strong>Estado:</strong> {p.estado}
              </p>

              {p.estado === "Disponible" && (
                <button
                  onClick={() => handleSolicitar(p.id)}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700"
                >
                  Solicitar material
                </button>
              )}
              {p.estado === "Reservado" && (
                <button className="bg-gray-400 text-white px-4 py-2 rounded-lg cursor-not-allowed">
                  Reservado
                </button>
              )}
            </div>

            {/* Placeholder de imagen */}
            <div className="flex-shrink-0 w-48 md:w-64 h-48 md:h-64 bg-gray-200 rounded-xl flex items-center justify-center text-gray-500 font-semibold">
              Imagen
            </div>
          </div>
        ))}
      </div>

      {/* Paginación simulada */}
      <div className="mt-8 flex justify-center gap-2">
        <button className="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100">
          1
        </button>
        <button className="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100">
          2
        </button>
        <button className="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100">
          3
        </button>
      </div>
    </main>
  );
}