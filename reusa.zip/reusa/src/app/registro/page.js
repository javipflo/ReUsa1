"use client";

export default function Registro() {
  const handleRegistro = (e) => {
    e.preventDefault();
    alert("Cuenta creada correctamente. Luego esta función se conectará a Supabase.");
  };

  return (
    <main className="min-h-screen bg-[#f5f7f5] px-6 md:px-10 py-10 text-gray-900">
      <section className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-purple-700 mb-4">
            Crear cuenta
          </h1>

          <p className="text-gray-600 text-lg leading-relaxed">
            Regístrate en ReUsa para publicar materiales, solicitar productos
            disponibles y coordinar el retiro con otros usuarios.
          </p>

          <div className="mt-8 bg-white rounded-2xl shadow-md p-6 border border-gray-100">
            <h2 className="text-2xl font-bold text-purple-600 mb-3">
              ¿Qué podrás hacer?
            </h2>
            <ul className="text-gray-700 space-y-2">
              <li>✅ Publicar cartón, latas o vidrio.</li>
              <li>✅ Solicitar materiales disponibles.</li>
              <li>✅ Coordinar retiro con otros usuarios.</li>
              <li>✅ Recibir información de centros cercanos.</li>
            </ul>
          </div>
        </div>

        <form
          onSubmit={handleRegistro}
          className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 md:p-8"
        >
          <h2 className="text-2xl font-bold text-purple-700 mb-6">
            Registro de usuario
          </h2>

          <div className="mb-5">
            <label className="block font-semibold mb-2">Nombre completo</label>
            <input
              type="text"
              placeholder="Ingresa tu nombre"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div className="mb-5">
            <label className="block font-semibold mb-2">Correo electrónico</label>
            <input
              type="email"
              placeholder="ejemplo@correo.com"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div className="mb-5">
            <label className="block font-semibold mb-2">Contraseña</label>
            <input
              type="password"
              placeholder="Crea una contraseña"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div className="mb-6">
            <label className="block font-semibold mb-2">Comuna</label>
            <input
              type="text"
              placeholder="Ej: Ñuñoa"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 transition"
          >
            Crear cuenta
          </button>

          <p className="text-center text-gray-600 mt-5">
            ¿Ya tienes cuenta?{" "}
            <a href="/login" className="text-purple-600 font-bold hover:underline">
              Inicia sesión aquí
            </a>
          </p>
        </form>
      </section>
    </main>
  );
}