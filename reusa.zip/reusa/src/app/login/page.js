"use client";

import { useState } from "react";

export default function Login() {
  const [rol, setRol] = useState("usuario");

  const handleLogin = (e) => {
    e.preventDefault();

    if (rol === "admin") {
      alert("Inicio de sesión como administrador. Luego redirigirá al panel admin.");
    } else {
      alert("Inicio de sesión como usuario. Luego permitirá publicar y solicitar materiales.");
    }
  };

  return (
    <main className="min-h-screen bg-[#f5f7f5] px-6 md:px-10 py-10 text-gray-900">
      <section className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-purple-700 mb-4">
            Iniciar sesión
          </h1>

          <p className="text-gray-600 text-lg leading-relaxed">
            Ingresa a ReUsa para publicar materiales, solicitar productos
            disponibles o acceder al panel de administrador según tu rol.
          </p>

          <div className="mt-8 bg-white rounded-2xl shadow-md p-6 border border-gray-100">
            <h2 className="text-2xl font-bold text-purple-600 mb-3">
              ¿Para qué sirve iniciar sesión?
            </h2>
            <ul className="text-gray-700 space-y-2">
              <li>✅ Publicar materiales reutilizables.</li>
              <li>✅ Solicitar o reservar materiales disponibles.</li>
              <li>✅ Coordinar contacto con otros usuarios.</li>
              <li>✅ Acceder al panel de administrador si corresponde.</li>
            </ul>
          </div>
        </div>

        <form
          onSubmit={handleLogin}
          className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 md:p-8"
        >
          <h2 className="text-2xl font-bold text-purple-700 mb-6">
            Acceso a la plataforma
          </h2>

          <div className="mb-5">
            <label className="block font-semibold mb-2">Correo electrónico</label>
            <input
              type="email"
              placeholder="ejemplo@correo.com"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div className="mb-5">
            <label className="block font-semibold mb-2">Contraseña</label>
            <input
              type="password"
              placeholder="Ingresa tu contraseña"
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <div className="mb-6">
            <label className="block font-semibold mb-2">Tipo de acceso</label>
            <select
              value={rol}
              onChange={(e) => setRol(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-400"
            >
              <option value="usuario">Usuario</option>
              <option value="admin">Administrador</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 transition"
          >
            Iniciar sesión
          </button>

          <p className="text-center text-gray-600 mt-5">
            ¿No tienes cuenta?{" "}
            <a href="/registro" className="text-purple-600 font-bold hover:underline">
              Regístrate aquí
            </a>
          </p>
        </form>
      </section>
    </main>
  );
}